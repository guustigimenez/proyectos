package TATETI;

public class Oponente {

}
