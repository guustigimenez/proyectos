package TATETI;

public class test {

	public static void main(String[] args) {

		Tablero tab1 = new Tablero();

		tab1.generateTab();
		tab1.mostrarTablero();
		Jugador j1 = new Jugador("X", "Gusti", tab1);
		Jugador j2 = new Jugador("0", "Sofi", tab1);

		boolean gan = false;

		while (gan == false) {
			j1.jugar();
			tab1.mostrarTablero();
			if (!(gan = tab1.hayTateti())) {
				j2.jugar();
				tab1.mostrarTablero();
				gan = tab1.hayTateti();
			}

		}

		if (gan == true) {
			if (tab1.getFichaGanadora().equals(j1.getFicha())) {
				System.out.println("El ganador fue: " + j1.getNombre() + "\nFelicitaciones!!");
			} else {
				System.out.println("El ganador del tateti fue: " + j2.getNombre() + "\nFelicitaciones!!");
			}
		}
	}
}
