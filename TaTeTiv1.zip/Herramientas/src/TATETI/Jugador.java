package TATETI;

import java.util.Scanner;

public class Jugador {

	private String ficha;
	private String nombre;
	public Tablero tablero;
	
	public void jugar(){
		
		int f= 0; int c = 0;
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Ingrese un numero del 1 al 9"+"\nJugador: "+this.nombre+"\nFicha: "+this.ficha);
		int j = s.nextInt();
		
		switch(j){
		default: System.out.println("Valor incorrecto..");break;
		case 1: f=2;c=0; break;
		case 2: f=2;c=1;break;
		case 3: f=2;c=2;break;
		case 4: f=1;c=0;break;
		case 5: f=1;c=1;break;
		case 6: f=1;c=2;break;
		case 7: f=0;c=0;break;
		case 8: f=0;c=1;break;
		case 9: f=0;c=2;break;
	
		}
		if(tablero.ponerFicha(f, c, ficha)== false){
			System.out.println("Lugar ocupado...Pierdes el turno.");
		}
	
	}
	
	public String getFicha(){
		return ficha;
	}
	public String getNombre(){
		return nombre;
	}
	
	Jugador(String ficha, String nombre, Tablero t){
		this.ficha = ficha;
		this.nombre = nombre;
		this.tablero = t;
	}
}
